// بدّل PAGE_USERNAME باسم المستخدم تاع صفحة Facebook. مثال: globalstoredz
const PAGE_USERNAME = 'global.store.dz';
const products = [
 {id:1,name:'معطف أنيق',price:3500,type:'stock',emoji:'🧥',desc:'مثال توضيحي — بدّل الصورة والوصف والسعر.'},
 {id:2,name:'طقم أظافر',price:1500,type:'order',emoji:'💅',desc:'مثال توضيحي — سور كوموند.'},
 {id:3,name:'حقيبة نسائية',price:2800,type:'stock',emoji:'👜',desc:'مثال توضيحي — متوفر في الستوك.'},
 {id:4,name:'إكسسوارات',price:1200,type:'order',emoji:'✨',desc:'مثال توضيحي — سور كوموند.'}
];
const cart = {}; let currentFilter='all';
const money=n=>new Intl.NumberFormat('fr-DZ').format(n);
function renderProducts(){const el=document.getElementById('products');el.innerHTML='';products.filter(p=>currentFilter==='all'||p.type===currentFilter).forEach(p=>{const card=document.createElement('article');card.className='product';card.innerHTML=`<div class="photo">${p.emoji}</div><div class="info"><h3>${p.name}</h3><div class="price">${money(p.price)} دج</div><span class="tag ${p.type==='order'?'pre':''}">${p.type==='stock'?'متوفر — الدفع عند الاستلام':'سور كوموند — الدفع مسبقاً'}</span><p class="small">${p.desc}</p><button class="btn primary" onclick="add(${p.id})">أضف إلى السلة</button></div>`;el.appendChild(card)});}
function add(id){cart[id]=(cart[id]||0)+1;renderCart()}
function change(id,d){cart[id]=(cart[id]||0)+d;if(cart[id]<=0)delete cart[id];renderCart()}
function getItems(){return products.filter(p=>cart[p.id]).map(p=>({...p,qty:cart[p.id]}))}
function renderCart(){const items=getItems();document.getElementById('count').textContent=items.reduce((a,p)=>a+p.qty,0);document.getElementById('total').textContent=money(items.reduce((a,p)=>a+p.price*p.qty,0));const el=document.getElementById('cartitems');if(!items.length){el.textContent='السلة فارغة، زيد المنتجات لي حابهم.';document.getElementById('paymentnote').textContent='طريقة الدفع تتحدد حسب المنتجات الموجودة في السلة.';return;}el.innerHTML=items.map(p=>`<div class="cartrow"><div><b>${p.name}</b><div class="small">${p.type==='stock'?'الدفع عند الاستلام':'الدفع مسبقاً'} · ${money(p.price*p.qty)} دج</div></div><div class="qty"><button onclick="change(${p.id},-1)">−</button><span>${p.qty}</span><button onclick="change(${p.id},1)">+</button></div></div>`).join('');const hasStock=items.some(p=>p.type==='stock'),hasOrder=items.some(p=>p.type==='order');document.getElementById('paymentnote').textContent=hasStock&&hasOrder?'طلبك فيه ستوك وسور كوموند: الدفع عند الاستلام للستوك، والدفع المسبق لمنتجات سور كوموند. أكّد تفاصيل الدفع مع المتجر قبل الإتمام.':hasOrder?'كل المنتجات سور كوموند: الدفع مسبقاً قبل تأكيد الطلب.':'كل المنتجات متوفرة: الدفع عند الاستلام.';}
function orderText(){const items=getItems();return `طلب جديد — Global Store Dz\n${items.map(p=>`- ${p.name} × ${p.qty} = ${money(p.price*p.qty)} دج (${p.type==='stock'?'متوفر، الدفع عند الاستلام':'سور كوموند، الدفع مسبقاً'})`).join('\n')}\nالمجموع: ${money(items.reduce((a,p)=>a+p.price*p.qty,0))} دج\nالاسم: ${document.getElementById('customer').value} ${document.getElementById('surname').value}\nالهاتف: ${document.getElementById('phone').value}\nالولاية: ${document.getElementById('province').value}\nالبلدية: ${document.getElementById('municipality').value}\nالعنوان: ${document.getElementById('address').value}\nالتوصيل: ${document.getElementById('delivery').value}`}
document.getElementById('filters').addEventListener('click',e=>{if(e.target.dataset.filter){currentFilter=e.target.dataset.filter;document.querySelectorAll('#filters button').forEach(b=>b.classList.toggle('active',b===e.target));renderProducts()}});

document.getElementById('send').addEventListener('click',async()=>{
  const items=getItems();
  if(!items.length){alert('السلة فارغة. زيد منتج أولاً.');return;}
  const fields=['customer','surname','phone','province','municipality','address'];
  if(fields.some(id=>!document.getElementById(id).value.trim())){
    alert('عمّر الاسم واللقب ورقم الهاتف والولاية والبلدية والعنوان أولاً.');return;
  }
  if(!document.getElementById('delivery').value){alert('اختار طريقة التوصيل أولاً.');return;}

  const details=orderText();
  const messengerUrl='https://m.me/global.store.dz';
  const btn=document.getElementById('send');
  btn.disabled=true;btn.textContent='نحضّر تفاصيل الطلب...';
  let copied=false;
  try {
    if(navigator.clipboard && navigator.clipboard.writeText){
      await navigator.clipboard.writeText(details);copied=true;
    } else {
      const box=document.createElement('textarea');box.value=details;
      box.style.position='fixed';box.style.opacity='0';document.body.appendChild(box);box.focus();box.select();
      copied=document.execCommand('copy');box.remove();
    }
  } catch(e) { copied=false; }

  // Messenger does not permit a static website to send a message silently.
  // The customer must paste the order and press Send in Messenger.
  const w=window.open(messengerUrl,'_blank');
  if(!w) window.location.href=messengerUrl;
  if(copied){
    alert('تفاصيل الطلب تنسخت. في Messenger الصقها في محادثة الصفحة واضغط إرسال باش توصلك الطلبية.');
  } else {
    const old=document.getElementById('order-copy-fallback');if(old)old.remove();
    const wrap=document.createElement('div');wrap.id='order-copy-fallback';wrap.className='notice';
    const title=document.createElement('p');title.textContent='انسخ تفاصيل الطلب التالية، ثم افتح Messenger والصقها في محادثة الصفحة واضغط إرسال:';
    const box=document.createElement('textarea');box.value=details;box.style.width='100%';box.style.minHeight='180px';box.setAttribute('aria-label','تفاصيل الطلب للنسخ');
    wrap.appendChild(title);wrap.appendChild(box);document.getElementById('cart').appendChild(wrap);box.focus();box.select();
    alert('ما قدرناش ننسخو الطلب تلقائياً. التفاصيل ظهرت تحت السلة؛ انسخها وأرسلها في Messenger.');
  }
  btn.disabled=false;btn.textContent='إرسال الطلب عبر Messenger';
});
renderProducts();renderCart();
